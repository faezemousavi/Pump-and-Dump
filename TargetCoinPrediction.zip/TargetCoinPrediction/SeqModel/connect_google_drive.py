import pandas as pd
df = pd.read_csv('TargetCoinPrediction/SeqModel/train_sample.csv')
print(df)
